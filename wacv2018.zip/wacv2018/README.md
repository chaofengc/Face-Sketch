## Paper Draft - Self-Supervised 3D Face Reconstruction from Single Image

### [draft v1](draft_v1.pdf)
